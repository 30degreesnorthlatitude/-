﻿# dsh-locale-zh — DeepSeek Harness Web UI 中文汉化插件

将 DeepSeek Harness Web 界面中**未走本地化系统、硬编码为英文**的 UI 文本汉化为简体中文。它是在浏览器端运行的**永久性组合插件**：随 `dsh web` 启动自动加载，**不需要审批，进程重启不会丢失**，也不修改任何官方文件。

## 汉化范围

- 权限选择器：`Read Only / Workspace Write / Full access / Custom` → 只读 / 工作区写入 / 完全访问 / 自定义（含描述）
- 斜杠命令描述：`/plan`、`/model`、`/feedback`、`/compact`、`/goal`、`/permission`、`/export`
- AI 推理等级：`Off / High / Max / Default` → 关闭 / 高 / 最高 / 默认
- 右上角「会话日志」按钮、计划模式 chip、技能标签
- 主对话状态：AI 思考时的 `Think` → 思考、工作时的 `Deep diving...` → 深度思考中…
- 工具卡片：`Read / Search / Grep / Glob / Bash / Pwsh / Write / Edit / Code / Tool call` 等标题（Pwsh/Bash → 终端），以及 `think · …` 等未知工具摘要前缀
- 轨迹 / 详情面板：工具栏、标签页（摘要/选项/用量/耗时/预览/原始…）、记录类型（系统/用户/工具…）、动态文本（`Turn 3` → 轮次 3、`3 tool calls` → 3 次工具调用、`Total / Started / TTFT / Decoding` 等）

技术原理：DOM 文本层替换（精确整节点匹配 + 轨迹面板特定容器内的正则），不会误伤聊天正文。

## 安装（约 10 秒）

1. 解压本压缩包到任意目录。
2. **先关闭正在运行的 `dsh web`**（或保持运行也行，HMR 会自动重载）。
3. 右键 `install.ps1` →「使用 PowerShell 运行」；或在终端执行：
   ```
   powershell -ExecutionPolicy Bypass -File .\install.ps1
   ```
4. 重启（或等待 HMR 重载后）刷新浏览器页面（F5 / Cmd+R）。

脚本会自动：
- 定位 `$DSH_HOME`（默认 `%USERPROFILE%\.dsh`，可用环境变量 `DSH_HOME` 覆盖）；
- 将插件包复制到 `$DSH_HOME\node_modules\dsh-locale-zh\`；
- 在 `$DSH_HOME\cordis.patch.yml` 中追加一行组合配置（幂等，重复运行不会重复追加）。

## 卸载

```
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1
```

## 自定义词条

编辑 `dsh-locale-zh\lib\client.js` 中的 `LABELS` / `TITLES` / `TOOL_TITLES_ZH` / `TOOL_NAMES_ZH` 字典，保存后刷新页面即可生效（组合插件由 `dsh-web` 的 client-modules 按内容哈希伺服，无需重新构建）。

## 兼容性

- 需要 DeepSeek Harness `dsh web`（本包基于 0.1.0-rc.6 验证）。
- 仅作用于浏览器 UI 文本；不修改任何 `node_modules` 官方文件，升级 harness 不影响本插件（升级会覆盖官方包，但本包位于用户目录）。
- 如机器上同时运行了旧版「动态 Cordis 汉化插件」，两者可共存（翻译幂等），卸载其一即可。
