﻿# dsh-locale-zh 卸载脚本
# 移除：$DSH_HOME/cordis.patch.yml 中的 dsh-locale-zh 配置行 + 插件包目录。
# 执行：powershell -ExecutionPolicy Bypass -File .\uninstall.ps1
$ErrorActionPreference = 'Stop'

$dshHome = if ($env:DSH_HOME -and $env:DSH_HOME.Trim() -ne '') { $env:DSH_HOME.Trim() } else { Join-Path $HOME '.dsh' }

# 1) 从 cordis.patch.yml 中移除 dsh-locale-zh 配置块（从标记注释行起删除到文件末尾）
$patch = Join-Path $dshHome 'cordis.patch.yml'
if (Test-Path -LiteralPath $patch) {
  $lines = [System.Collections.Generic.List[string]]([System.IO.File]::ReadAllLines($patch))
  $marker = -1
  for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\s*#\s*dsh-locale-zh\s*:' -or $lines[$i] -match '^\s*#\s*DeepSeek Harness UI 中文汉化') { $marker = $i; break }
  }
  if ($marker -ge 0) {
    $lines.RemoveRange($marker, $lines.Count - $marker)
    # 若剩余内容仅为注释/空白，则整个删除补丁文件
    $remaining = $lines | Where-Object { $_ -match '\S' -and $_ -notmatch '^\s*#' }
    if (@($remaining).Count -eq 0) {
      Remove-Item -LiteralPath $patch -Force
      Write-Host "组合配置已清空并删除：$patch"
    } else {
      $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
      [System.IO.File]::WriteAllText($patch, ($lines -join "`n").TrimEnd("`n") + "`n", $utf8NoBom)
      Write-Host "已从组合配置移除 dsh-locale-zh：$patch"
    }
  } else {
    Write-Host "组合配置中未找到 dsh-locale-zh 标记，跳过：$patch"
  }
} else {
  Write-Host "组合配置不存在，跳过：$patch"
}

# 2) 删除插件包目录（home 主目录 + 各 profile 下的嵌套副本）
$homePkg = Join-Path $dshHome 'node_modules\dsh-locale-zh'
if (Test-Path -LiteralPath $homePkg) {
  Remove-Item -LiteralPath $homePkg -Recurse -Force
  Write-Host "已删除插件包：$homePkg"
}
# 兜底：清理可能存在于各 profile node_modules 的旧副本/嵌套副本
$profilesDir = Join-Path $dshHome 'profiles'
if (Test-Path -LiteralPath $profilesDir) {
  Get-ChildItem -LiteralPath $profilesDir -Directory -Filter 'dsh-locale-zh' -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
    Remove-Item -LiteralPath $_.FullName -Recurse -Force
    Write-Host "已删除插件包：$($_.FullName)"
  }
}

Write-Host ''
Write-Host '卸载完成。重启 dsh web 并刷新页面后汉化即失效。' -ForegroundColor Green
