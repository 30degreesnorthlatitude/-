﻿# dsh-locale-zh 安装脚本
# 作用：将中文汉化插件安装到本机 DeepSeek Harness (dsh web)。
# 安装方式：右键“使用 PowerShell 运行”，或在 PowerShell 中执行
#   powershell -ExecutionPolicy Bypass -File .\install.ps1
$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pkgDir = Join-Path $scriptDir 'dsh-locale-zh'
$dshHome = if ($env:DSH_HOME -and $env:DSH_HOME.Trim() -ne '') { $env:DSH_HOME.Trim() } else { Join-Path $HOME '.dsh' }

if (-not (Test-Path -LiteralPath $pkgDir)) { Write-Host "错误：找不到插件目录 $pkgDir" -ForegroundColor Red; exit 1 }
if (-not (Test-Path -LiteralPath $dshHome)) { Write-Host "错误：找不到 DSH 配置目录 $dshHome（请先运行过一次 dsh web）" -ForegroundColor Red; exit 1 }

Write-Host "DSH_HOME: $dshHome"

# 1) 复制插件包到 $DSH_HOME/node_modules（任意 profile 都会通过 Node 向上查找解析到它）
$target = Join-Path $dshHome 'node_modules\dsh-locale-zh'
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
# 重复安装时先清掉旧目录，避免 Copy-Item 嵌套复制
if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
Copy-Item -LiteralPath $pkgDir -Destination $target -Recurse -Force
Write-Host "已复制插件包 -> $target"

# 2) 在 $DSH_HOME/cordis.patch.yml 中追加组合配置行（幂等：已存在则跳过）
$patch = Join-Path $dshHome 'cordis.patch.yml'
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$block = @"

# dsh-locale-zh: DeepSeek Harness UI 中文汉化（DOM 文本层替换硬编码英文）
- insert:
    - id: dsh-locale-zh
      name: 'dsh-locale-zh'
"@

if (Test-Path -LiteralPath $patch) {
  $existing = [System.IO.File]::ReadAllText($patch)
  if ($existing -match 'dsh-locale-zh') {
    Write-Host "组合配置已包含 dsh-locale-zh，跳过修改：$patch"
  } else {
    $new = $existing.TrimEnd("`r", "`n") + "`n" + $block + "`n"
    [System.IO.File]::WriteAllText($patch, $new, $utf8NoBom)
    Write-Host "已追加组合配置 -> $patch"
  }
} else {
  $header = '# dsh home patch — 应用于本机所有 profile（机器级偏好）。' + "`n"
  [System.IO.File]::WriteAllText($patch, $header + $block + "`n", $utf8NoBom)
  Write-Host "已创建组合配置 -> $patch"
}

Write-Host ''
Write-Host '安装完成！' -ForegroundColor Green
Write-Host '下一步：'
Write-Host '  1. 重启 dsh web（或等待 HMR 自动重载组合配置，无需重启也能生效）；'
Write-Host '  2. 刷新浏览器页面（F5 / Cmd+R）。'
Write-Host '之后无需任何审批，重启进程也不会丢失汉化。'
